"""Validate on held-out mice or generate the 29-row Kaggle submission."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from cellmatch import (ROOT, labels_to_rles, pq_score, read_image, region_centers,
                       rle_to_labels, write_submission)
from learned import load_model, predict_probabilities, probabilities_to_labels
from registration import match_points, register_with_priors


def predicted_to_ground_truth(pred: np.ndarray, truth: np.ndarray) -> dict[int, int]:
    npred, ngt = int(pred.max()), int(truth.max())
    if not npred or not ngt:
        return {}
    joint = np.bincount((pred.astype(np.int64) * (ngt + 1) + truth).ravel(),
                        minlength=(npred + 1) * (ngt + 1)).reshape(npred + 1, ngt + 1)
    pc = joint.sum(axis=1)
    gc = joint.sum(axis=0)
    rows, cols = np.nonzero(joint[1:, 1:])
    rows += 1
    cols += 1
    iou = joint[rows, cols] / (pc[rows] + gc[cols] - joint[rows, cols])
    return {int(p): int(g) for p, g, score in zip(rows, cols, iou) if score > 0.75}


def predict_one(path: Path, iv_model, ex_model, device: str, tta: bool,
                iv_threshold: float, ex_threshold: float) -> dict:
    images = {}
    labels = {}
    centers = {}
    for modality, model, threshold in (("invivo", iv_model, iv_threshold),
                                       ("exvivo", ex_model, ex_threshold)):
        image = read_image(path / f"{modality}.tif")
        probs = predict_probabilities(model, image, modality, device=device, tta=tta)
        instances = probabilities_to_labels(probs, modality, threshold, 0.5)
        images[modality] = image
        labels[modality] = instances
        centers[modality] = region_centers(instances)
    positive = register_with_priors(centers["invivo"], centers["exvivo"], mode=0)
    negative = register_with_priors(centers["invivo"], centers["exvivo"], mode=1)
    return {"images": images, "labels": labels, "centers": centers,
            "registration": (positive, negative)}


def subject_mode(items: list[dict]) -> int | None:
    ratios = []
    for item in items:
        positive, negative = item["registration"]
        ratios.append((positive[1] + 1) / (negative[1] + 1))
    ratios = np.asarray(ratios)
    if np.mean(ratios > 1.13) >= 0.65:
        return 0
    if np.mean(ratios < 1 / 1.13) >= 0.65:
        return 1
    return None


def select_registration(item: dict, mode: int | None) -> tuple[np.ndarray | None, float, int]:
    candidates = item["registration"]
    return candidates[mode] if mode is not None else max(candidates, key=lambda x: x[1])


def validate(frame: pd.DataFrame, records: dict, threshold_list=(4, 5, 6, 7, 8)):
    pq = {"invivo": [], "exvivo": []}
    counts = {distance: [0, 0, 0] for distance in threshold_list}
    for subject, group in frame.groupby(frame.sample_id.str.split("__").str[0], sort=False):
        mode = subject_mode([records[row.sample_id] for row in group.itertuples(index=False)])
        print(f"{subject} subject-level mode: {mode}", flush=True)
        for row in group.itertuples(index=False):
            item = records[row.sample_id]
            matrix, score, chosen_mode = select_registration(item, mode)
            mappings = {}
            gt_ids = {}
            for modality in ("invivo", "exvivo"):
                ground_truth, ids = rle_to_labels(json.loads(getattr(row, f"{modality}_instances")),
                                                  item["images"][modality].shape)
                pred = item["labels"][modality]
                pq[modality].append(pq_score(pred, ground_truth)[0])
                mappings[modality] = predicted_to_ground_truth(pred, ground_truth)
                gt_ids[modality] = ids
            truth_pairs = {tuple(pair) for pair in json.loads(row.match_pairs)}
            for distance in threshold_list:
                pairs = [] if matrix is None else match_points(item["centers"]["invivo"],
                                                                item["centers"]["exvivo"], matrix, distance)
                correct = 0
                for iv_index, ex_index, _ in pairs:
                    iv_gt = mappings["invivo"].get(iv_index + 1)
                    ex_gt = mappings["exvivo"].get(ex_index + 1)
                    if iv_gt is not None and ex_gt is not None and (
                        gt_ids["invivo"][iv_gt - 1], gt_ids["exvivo"][ex_gt - 1]
                    ) in truth_pairs:
                        correct += 1
                counts[distance][0] += correct
                counts[distance][1] += len(pairs) - correct
                counts[distance][2] += len(truth_pairs) - correct
            print(row.sample_id, "PQ", round(pq["invivo"][-1], 3), round(pq["exvivo"][-1], 3),
                  "cells", len(item["centers"]["invivo"]), len(item["centers"]["exvivo"]),
                  "registration", chosen_mode, round(score, 1), flush=True)
    iv_pq, ex_pq = np.mean(pq["invivo"]), np.mean(pq["exvivo"])
    print("Mean PQ", iv_pq, ex_pq, flush=True)
    for distance, (tp, fp, fn) in counts.items():
        f1 = 2 * tp / (2 * tp + fp + fn) if tp else 0
        final = 0.25 * (iv_pq + ex_pq) + 0.5 * f1
        print(f"distance {distance}: TP={tp} FP={fp} FN={fn} F1={f1:.4f} final={final:.4f}", flush=True)


def submit(frame: pd.DataFrame, records: dict, output: Path, match_distance: float):
    rows = []
    for subject, group in frame.groupby(frame.sample_id.str.split("__").str[0], sort=False):
        mode = subject_mode([records[row.sample_id] for row in group.itertuples(index=False)])
        print(f"{subject} subject-level mode: {mode}", flush=True)
        for row in group.itertuples(index=False):
            item = records[row.sample_id]
            matrix, score, chosen_mode = select_registration(item, mode)
            iv = labels_to_rles(item["labels"]["invivo"], "IVP")
            ex = labels_to_rles(item["labels"]["exvivo"], "EXP")
            pairs = []
            if matrix is not None:
                pairs = [[f"IVP_{i+1:06d}", f"EXP_{j+1:06d}"] for i, j, _ in
                         match_points(item["centers"]["invivo"], item["centers"]["exvivo"],
                                      matrix, match_distance)]
            print(row.sample_id, "cells", len(iv), len(ex), "pairs", len(pairs),
                  "registration", chosen_mode, round(score, 1), flush=True)
            rows.append({"sample_id": row.sample_id, "invivo_instances": iv,
                         "exvivo_instances": ex, "match_pairs": pairs})
    write_submission(rows, output)
    print(f"Saved {output} ({output.stat().st_size:,} bytes)", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["validate", "submit"], required=True)
    parser.add_argument("--subject", default="")
    parser.add_argument("--iv-model", type=Path, required=True)
    parser.add_argument("--ex-model", type=Path, required=True)
    parser.add_argument("--iv-threshold", type=float, default=0.5)
    parser.add_argument("--ex-threshold", type=float, default=0.55)
    parser.add_argument("--match-distance", type=float, default=6)
    parser.add_argument("--tta", action="store_true")
    parser.add_argument("--output", type=Path, default=Path("submission.csv"))
    args = parser.parse_args()
    device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
    torch.set_num_threads(4)
    iv_model = load_model(args.iv_model, device)
    ex_model = load_model(args.ex_model, device)
    if args.mode == "validate":
        if not args.subject:
            raise ValueError("--subject is required for validation")
        frame = pd.read_csv(ROOT / "training/train_ground_truth.csv")
        frame = frame[frame.sample_id.str.startswith(args.subject)]
        directory = ROOT / "training"
    else:
        frame = pd.read_csv(ROOT / "sample_submission.csv")
        directory = ROOT / "hidden_test"
    records = {}
    for row in frame.itertuples(index=False):
        path = directory / row.sample_id.replace("__", "/")
        records[row.sample_id] = predict_one(path, iv_model, ex_model, device, args.tta,
                                             args.iv_threshold, args.ex_threshold)
        print("inferred", row.sample_id, flush=True)
    if args.mode == "validate":
        validate(frame, records)
    else:
        submit(frame, records, args.output, args.match_distance)


if __name__ == "__main__":
    main()
