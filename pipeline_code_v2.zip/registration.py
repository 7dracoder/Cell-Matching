"""Robust registration of sparse cell centers across imaging modalities."""

from __future__ import annotations

import cv2
import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.optimize import linear_sum_assignment
from scipy.spatial import cKDTree


def transform(points: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    return points @ matrix[:, :2].T + matrix[:, 2]


def initial_candidates(invivo: np.ndarray, exvivo: np.ndarray, angle_limit: int = 45,
                       bin_size: float = 12, count: int = 36) -> list[np.ndarray]:
    """Hough voting for angle, scale, and translation from all point pairs."""
    if len(invivo) < 3 or len(exvivo) < 3:
        return []
    angles = np.arange(-angle_limit, angle_limit + 0.1, 3)
    scales = np.arange(0.79, 1.141, 0.04)
    pool = []
    # In-vivo coordinates are in a much smaller canvas; translations are bounded.
    limit = 2500
    bins = int(2 * limit / bin_size) + 1
    for angle in angles:
        theta = np.deg2rad(angle)
        base = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
        for scale in scales:
            linear = scale * base
            rotated = invivo @ linear.T
            differences = (exvivo[:, None, :] - rotated[None, :, :]).reshape(-1, 2)
            xy = np.floor((differences + limit) / bin_size).astype(np.int32)
            valid = (xy >= 0).all(axis=1) & (xy < bins).all(axis=1)
            votes = np.bincount(xy[valid, 1] * bins + xy[valid, 0], minlength=bins * bins)
            peak_ids = np.argpartition(votes, -3)[-3:]
            for peak in peak_ids:
                ix, iy = peak % bins, peak // bins
                around = (np.abs(xy[valid, 0] - ix) <= 1) & (np.abs(xy[valid, 1] - iy) <= 1)
                if around.sum() < 3:
                    continue
                shift = np.median(differences[valid][around], axis=0)
                matrix = np.c_[linear, shift]
                _, _, distances = paired_nearest(invivo, exvivo, matrix, 16)
                score = np.maximum(0, 1 - distances / 16).sum()
                pool.append((float(score), matrix))
    pool.sort(key=lambda pair: pair[0], reverse=True)
    return [matrix for _, matrix in pool[:count]]


def fixed_linear_candidates(invivo: np.ndarray, exvivo: np.ndarray, linear: np.ndarray,
                            bin_size: float = 8, count: int = 20) -> list[np.ndarray]:
    """Find translations when a subject-level linear transform is known approximately."""
    differences = (exvivo[:, None, :] - (invivo @ linear.T)[None, :, :]).reshape(-1, 2)
    limit = 2500
    bins = int(2 * limit / bin_size) + 1
    xy = np.floor((differences + limit) / bin_size).astype(np.int32)
    valid = (xy >= 0).all(axis=1) & (xy < bins).all(axis=1)
    histogram = np.bincount(xy[valid, 1] * bins + xy[valid, 0], minlength=bins * bins).reshape(bins, bins)
    histogram = gaussian_filter(histogram.astype(np.float32), 0.8)
    pool = []
    for _ in range(count):
        peak = np.unravel_index(np.argmax(histogram), histogram.shape)
        if histogram[peak] == 0:
            break
        nearby = (np.abs(xy[valid, 0] - peak[1]) <= 2) & (np.abs(xy[valid, 1] - peak[0]) <= 2)
        shift = np.median(differences[valid][nearby], axis=0)
        pool.append(np.c_[linear, shift])
        y, x = peak
        histogram[max(0, y - 3) : y + 4, max(0, x - 3) : x + 4] = 0
    return pool


def paired_nearest(invivo: np.ndarray, exvivo: np.ndarray, matrix: np.ndarray,
                   distance: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    projected = transform(invivo, matrix)
    tree = cKDTree(exvivo)
    nearest_distance, nearest_index = tree.query(projected, distance_upper_bound=distance)
    valid = np.isfinite(nearest_distance)
    sources = np.flatnonzero(valid)
    if not len(sources):
        return np.array([], int), np.array([], int), np.array([], float)
    destinations = nearest_index[valid]
    distances = nearest_distance[valid]
    # Retain a single source for each ex-vivo cell.
    order = np.argsort(distances)
    used = set()
    keep = []
    for k in order:
        if int(destinations[k]) not in used:
            used.add(int(destinations[k]))
            keep.append(k)
    return sources[keep], destinations[keep], distances[keep]


def refine(invivo: np.ndarray, exvivo: np.ndarray, initial: np.ndarray) -> tuple[np.ndarray, float]:
    matrix = initial.copy()
    for distance in (30, 20, 12, 7):
        sources, destinations, _ = paired_nearest(invivo, exvivo, matrix, distance)
        if len(sources) < 3:
            break
        fit, inliers = cv2.estimateAffine2D(invivo[sources], exvivo[destinations],
                                             method=cv2.RANSAC, ransacReprojThreshold=max(4, distance * 0.5),
                                             maxIters=2000, refineIters=20)
        if fit is None or not 0.65 < abs(np.linalg.det(fit[:, :2])) < 1.3:
            break
        matrix = fit
    _, _, distances = paired_nearest(invivo, exvivo, matrix, 8)
    # True registrations support many close, unique cell pairs.
    score = len(distances) + np.sum(np.maximum(0, 1 - distances / 8))
    return matrix, float(score)


def register_points(invivo: np.ndarray, exvivo: np.ndarray) -> tuple[np.ndarray | None, float]:
    candidates = initial_candidates(invivo, exvivo)
    if not candidates:
        return None, 0
    results = [refine(invivo, exvivo, candidate) for candidate in candidates]
    return max(results, key=lambda result: result[1])


# Median in-vivo to ex-vivo linear transforms estimated from the 47 labeled
# regions, using verified pairs only.  Translation is estimated per region.
TRAINING_LINEAR_PRIORS = (
    np.array([[0.967, -0.161], [0.121, 0.909]], dtype=np.float32),
    np.array([[0.982, 0.227], [-0.256, 0.927]], dtype=np.float32),
)


def register_with_priors(invivo: np.ndarray, exvivo: np.ndarray,
                         mode: int | None = None) -> tuple[np.ndarray | None, float, int]:
    """Search label-derived geometric priors and solve translation from data."""
    if len(invivo) < 3 or len(exvivo) < 3:
        return None, 0, -1
    results = []
    modes = range(len(TRAINING_LINEAR_PRIORS)) if mode is None else (mode,)
    for mode_index in modes:
        base = TRAINING_LINEAR_PRIORS[mode_index]
        for angle in (-5, 0, 5):
            theta = np.deg2rad(angle)
            rotation = np.array([[np.cos(theta), -np.sin(theta)],
                                 [np.sin(theta), np.cos(theta)]])
            for scale in (0.95, 1.0, 1.05):
                linear = (scale * rotation @ base).astype(np.float32)
                for candidate in fixed_linear_candidates(invivo, exvivo, linear, count=4):
                    matrix, score = refine(invivo, exvivo, candidate)
                    results.append((matrix, score, mode_index))
    return max(results, key=lambda item: item[1]) if results else (None, 0, -1)


def match_points(invivo: np.ndarray, exvivo: np.ndarray, matrix: np.ndarray,
                 max_distance: float = 5.0) -> list[tuple[int, int, float]]:
    sources, destinations, distances = paired_nearest(invivo, exvivo, matrix, max_distance)
    return [(int(i), int(j), float(d)) for i, j, d in zip(sources, destinations, distances)]
